# LightSail Automation Bot

An automated tool for LightSail Education literacy platform that automatically reads books, flips pages every 2 minutes, and answers comprehension questions using AI.

## Features

- **Automatic Login**: Logs into LightSail with your credentials
- **Book Selection**: Automatically selects a book (or specify your preferred title)
- **Auto Page Flipping**: Flips pages every 2 minutes (configurable)
- **Question Detection**: Automatically detects and answers:
  - Multiple choice questions (4 options)
  - Fill-in-the-blank (Cloze) questions
  - Short answer questions
- **AI-Powered Answers**: Uses AI to intelligently answer questions
- **Screenshots**: Saves screenshots of questions for review
- **Session Logging**: Tracks pages read and questions answered

## Two Versions Available

### 1. `lightsail_bot.py` - OpenAI Version
Uses OpenAI GPT-3.5 for intelligent question answering. Requires an OpenAI API key.

**Pros:**
- High accuracy answers
- Context-aware responses
- Better comprehension

**Cons:**
- Requires OpenAI API key (costs money after free tier)

### 2. `lightsail_bot_free_ai.py` - FREE Version (Recommended)
Uses free pattern matching and optional Hugging Face API. No API key required!

**Pros:**
- Completely FREE
- Works without any API keys
- Pattern-based intelligent guessing
- Optional Hugging Face integration

**Cons:**
- Slightly less accurate than OpenAI (but still effective)

## Installation

### Step 1: Install Python
Make sure you have Python 3.8 or higher installed.

### Step 2: Install Dependencies

```bash
# Navigate to the project folder
cd lightsail-automation

# Install required packages
pip install -r requirements.txt

# Install Playwright browsers
playwright install chromium
```

### Step 3: Configure Your Credentials

Edit `config.json` with your LightSail credentials:

```json
{
  "username": "your_lightsail_username",
  "password": "your_lightsail_password",
  "openai_api_key": "sk-...",  (only for OpenAI version)
  "headless": false,
  "page_flip_interval": 120,
  "auto_answer_questions": true,
  "preferred_book_title": "",
  "screenshot_on_question": true
}
```

## Configuration Options

| Option | Description | Default |
|--------|-------------|---------|
| `username` | Your LightSail username | (required) |
| `password` | Your LightSail password | (required) |
| `openai_api_key` | OpenAI API key (for OpenAI version) | "" |
| `headless` | Run browser in background (no window) | false |
| `page_flip_interval` | Seconds between page flips | 120 |
| `auto_answer_questions` | Automatically answer questions | true |
| `preferred_book_title` | Specific book to read (empty = auto) | "" |
| `screenshot_on_question` | Save screenshots of questions | true |
| `use_ai` | (Free version) Use AI or random answers | true |

## Usage

### Run the FREE Version (Recommended)

```bash
python lightsail_bot_free_ai.py
```

### Run the OpenAI Version

```bash
python lightsail_bot.py
```

## How It Works

1. **Login**: Bot logs into LightSail with your credentials
2. **Book Selection**: Selects a book from your library
3. **Reading Loop**:
   - Checks for questions every cycle
   - If question found: Takes screenshot, answers using AI, submits
   - If no question: Flips to next page
   - Waits 2 minutes (configurable)
   - Repeats

## Question Answering

### Multiple Choice Questions
- Detects 4-option questions
- Uses AI to select best answer
- Clicks the selected option
- Submits the answer

### Fill-in-the-Blank (Cloze)
- Detects text input fields
- Uses context to determine appropriate words
- Fills in all blanks
- Submits the answer

### Short Answer
- Detects textarea fields
- Generates 2-3 sentence response
- Fills in the answer
- Submits

## Stopping the Bot

Press `Ctrl+C` at any time to stop the bot gracefully. It will show a summary of your session.

## Session Summary

When stopped, the bot displays:
- Book title
- Pages read
- Questions answered
- Total runtime

## Screenshots

Question screenshots are saved as:
- `question_mc_1.png` - Multiple choice questions
- `question_cloze_1.png` - Fill-in-the-blank questions
- `question_short_1.png` - Short answer questions

## Troubleshooting

### Login Issues
- Verify your username/password in `config.json`
- Check if LightSail website has changed
- Look at `login_failed.png` screenshot

### Book Not Found
- Try specifying exact book title in `preferred_book_title`
- Check `dashboard.png` to see available books

### Questions Not Detected
- LightSail may have updated their UI
- Check the screenshots to see page state
- Try adjusting selectors in the code

### Browser Issues
```bash
# Reinstall Playwright
playwright install --force chromium
```

## Safety & Ethics

⚠️ **Important Notes:**

1. **Educational Purpose**: This tool is for educational purposes and helping students with reading disabilities or time constraints.

2. **Terms of Service**: Using automation may violate LightSail's Terms of Service. Use at your own risk.

3. **Learning**: This tool should complement, not replace, actual reading and learning.

4. **Detection**: Automated behavior may be detectable by the platform.

## Customization

### Change Page Flip Speed
Edit `config.json`:
```json
{
  "page_flip_interval": 60  // 1 minute instead of 2
}
```

### Specify a Book
```json
{
  "preferred_book_title": "The Great Gatsby"
}
```

### Run in Background (Headless)
```json
{
  "headless": true
}
```

## Free AI Alternatives

The free version uses pattern matching. For better results without OpenAI:

1. **Hugging Face** (free tier available):
   - Sign up at huggingface.co
   - Get API token
   - Add to config: `"huggingface_api_key": "hf_..."`

2. **Local LLM** (advanced):
   - Run models like Llama 2 locally
   - Modify code to use local API endpoint

## Requirements

- Python 3.8+
- Playwright
- OpenAI Python library (for OpenAI version)
- Internet connection
- LightSail account

## File Structure

```
lightsail-automation/
├── lightsail_bot.py           # OpenAI version
├── lightsail_bot_free_ai.py   # FREE version (recommended)
├── config.json                # Your configuration
├── requirements.txt           # Python dependencies
├── README.md                  # This file
└── *.png                      # Screenshots (generated)
```

## Updates

LightSail may update their website, which could break selectors. If the bot stops working:

1. Check for error messages
2. Look at screenshots
3. Update selectors in the code
4. Test and verify

## Support

This is an open-source tool. For issues:
1. Check troubleshooting section
2. Review error logs
3. Update selectors if website changed

## License

MIT License - Free to use and modify

---

**Disclaimer**: This tool is provided as-is for educational purposes. The authors are not responsible for any consequences of using this automation tool.
