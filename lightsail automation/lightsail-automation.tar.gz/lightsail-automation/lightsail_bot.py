#!/usr/bin/env python3
"""
LightSail Automation Bot
Automatically reads books, flips pages, and answers comprehension questions
"""

import asyncio
import json
import time
import os
import re
from datetime import datetime
from typing import Optional, Dict, List, Tuple
from playwright.async_api import async_playwright, Page, Browser, ElementHandle
from dotenv import load_dotenv
import openai

# Load environment variables
load_dotenv()

class LightSailBot:
    def __init__(self):
        self.browser: Optional[Browser] = None
        self.page: Optional[Page] = None
        self.config = self._load_config()
        self.current_book = None
        self.page_flip_interval = 120  # 2 minutes in seconds
        self.is_running = False
        self.question_answered_count = 0
        self.pages_read = 0
        
        # Initialize OpenAI
        openai.api_key = self.config.get('openai_api_key', '')
        
    def _load_config(self) -> Dict:
        """Load configuration from config.json"""
        default_config = {
            "username": "",
            "password": "",
            "openai_api_key": "",
            "headless": False,
            "page_flip_interval": 120,
            "auto_answer_questions": True,
            "preferred_book_title": "",
            "reading_speed_wpm": 200,
            "screenshot_on_question": True,
            "log_level": "INFO"
        }
        
        if os.path.exists('config.json'):
            with open('config.json', 'r') as f:
                return {**default_config, **json.load(f)}
        return default_config
    
    def log(self, message: str, level: str = "INFO"):
        """Log messages with timestamp"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"[{timestamp}] [{level}] {message}")
    
    async def start(self):
        """Start the browser and navigate to LightSail"""
        self.log("Starting LightSail Automation Bot...")
        
        playwright = await async_playwright().start()
        self.browser = await playwright.chromium.launch(
            headless=self.config.get('headless', False),
            args=['--disable-blink-features=AutomationControlled']
        )
        
        context = await self.browser.new_context(
            viewport={'width': 1366, 'height': 768},
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        )
        
        self.page = await context.new_page()
        
        # Navigate to LightSail
        await self.page.goto("https://lightsailed.com/school/literacy/")
        await self.page.wait_for_load_state('networkidle')
        
        self.log("Browser started and navigated to LightSail")
        
    async def login(self):
        """Login to LightSail with credentials"""
        self.log("Attempting to login...")
        
        username = self.config.get('username')
        password = self.config.get('password')
        
        if not username or not password:
            self.log("ERROR: Username or password not configured in config.json", "ERROR")
            return False
        
        try:
            # Fill in username
            await self.page.fill('input[placeholder="Username"], input[name="username"], input[type="text"]', username)
            
            # Fill in password
            await self.page.fill('input[placeholder="Password"], input[name="password"], input[type="password"]', password)
            
            # Click login button
            await self.page.click('button:has-text("Log In"), button[type="submit"]')
            
            # Wait for navigation after login
            await self.page.wait_for_load_state('networkidle')
            await asyncio.sleep(3)
            
            # Check if login was successful
            if 'login' not in self.page.url.lower():
                self.log("Login successful!")
                return True
            else:
                self.log("ERROR: Login failed - still on login page", "ERROR")
                return False
                
        except Exception as e:
            self.log(f"ERROR during login: {str(e)}", "ERROR")
            return False
    
    async def select_book(self):
        """Select a book from the library"""
        self.log("Looking for books to select...")
        
        preferred_title = self.config.get('preferred_book_title', '')
        
        try:
            # Wait for the library to load
            await self.page.wait_for_selector('[data-testid="book"], .book-item, .library-item, .book-card', timeout=10000)
            
            if preferred_title:
                # Try to find the preferred book
                book_selector = f'text={preferred_title}'
                try:
                    await self.page.click(book_selector)
                    self.log(f"Selected preferred book: {preferred_title}")
                    self.current_book = preferred_title
                    return True
                except:
                    self.log(f"Preferred book '{preferred_title}' not found, selecting first available book")
            
            # Click on the first available book
            book_elements = await self.page.query_selector_all('[data-testid="book"], .book-item, .library-item, .book-card')
            
            if book_elements:
                await book_elements[0].click()
                self.log("Selected first available book")
                await asyncio.sleep(2)
                return True
            else:
                # Try alternative selectors
                await self.page.click('img[alt*="book"], .book-cover, .thumbnail')
                self.log("Selected book using alternative selector")
                return True
                
        except Exception as e:
            self.log(f"ERROR selecting book: {str(e)}", "ERROR")
            return False
    
    async def start_reading(self):
        """Start reading the selected book"""
        self.log("Starting to read...")
        self.is_running = True
        
        try:
            # Look for "Read" or "Start Reading" button
            read_buttons = [
                'button:has-text("Read")',
                'button:has-text("Start Reading")',
                'button:has-text("Open Book")',
                '.read-button',
                '[data-testid="read-button"]'
            ]
            
            for selector in read_buttons:
                try:
                    await self.page.click(selector, timeout=3000)
                    self.log("Clicked read button")
                    await asyncio.sleep(3)
                    break
                except:
                    continue
            
            # Main reading loop
            while self.is_running:
                await self.reading_cycle()
                
        except Exception as e:
            self.log(f"ERROR in reading loop: {str(e)}", "ERROR")
            self.is_running = False
    
    async def reading_cycle(self):
        """One cycle of reading: check for questions, flip page, wait"""
        try:
            # Check for questions first
            question_detected = await self.check_and_answer_questions()
            
            if not question_detected:
                # No question, flip the page
                await self.flip_page()
                self.pages_read += 1
                self.log(f"Pages read: {self.pages_read}")
            
            # Wait for the configured interval before next action
            self.log(f"Waiting {self.page_flip_interval} seconds before next action...")
            await asyncio.sleep(self.page_flip_interval)
            
        except Exception as e:
            self.log(f"ERROR in reading cycle: {str(e)}", "ERROR")
    
    async def check_and_answer_questions(self) -> bool:
        """Check for questions and answer them if found"""
        try:
            # Look for multiple choice questions
            mc_question = await self.detect_multiple_choice_question()
            if mc_question:
                self.log("Multiple choice question detected!")
                if self.config.get('auto_answer_questions', True):
                    await self.answer_multiple_choice_question(mc_question)
                return True
            
            # Look for fill-in-the-blank (cloze) questions
            cloze_question = await self.detect_cloze_question()
            if cloze_question:
                self.log("Fill-in-the-blank (Cloze) question detected!")
                if self.config.get('auto_answer_questions', True):
                    await self.answer_cloze_question(cloze_question)
                return True
            
            # Look for short answer questions
            short_answer = await self.detect_short_answer_question()
            if short_answer:
                self.log("Short answer question detected!")
                if self.config.get('auto_answer_questions', True):
                    await self.answer_short_answer_question(short_answer)
                return True
                
        except Exception as e:
            self.log(f"ERROR checking for questions: {str(e)}", "ERROR")
        
        return False
    
    async def detect_multiple_choice_question(self) -> Optional[Dict]:
        """Detect if a multiple choice question is present"""
        try:
            # Common selectors for MC questions
            mc_selectors = [
                '.multiple-choice',
                '.mc-question',
                '[data-testid="mc-question"]',
                '.question-container',
                '.quiz-question'
            ]
            
            for selector in mc_selectors:
                element = await self.page.query_selector(selector)
                if element:
                    # Get question text
                    question_text = await element.inner_text()
                    
                    # Get options (usually radio buttons or clickable options)
                    options = await element.query_selector_all(
                        'input[type="radio"], .option, .choice, label'
                    )
                    
                    if len(options) >= 2:  # At least 2 options
                        option_texts = []
                        for opt in options:
                            text = await opt.inner_text()
                            option_texts.append(text.strip())
                        
                        return {
                            'element': element,
                            'question': question_text,
                            'options': option_texts,
                            'option_elements': options
                        }
                        
        except Exception as e:
            pass
        
        return None
    
    async def detect_cloze_question(self) -> Optional[Dict]:
        """Detect fill-in-the-blank (cloze) questions"""
        try:
            # Look for input fields in the context of a question
            cloze_selectors = [
                '.cloze-question',
                '.fill-in-blank',
                'input[data-testid="cloze"]',
                '.blank-input'
            ]
            
            for selector in cloze_selectors:
                inputs = await self.page.query_selector_all(selector)
                if inputs:
                    # Get surrounding context
                    context = await self.page.evaluate('''() => {
                        const inputs = document.querySelectorAll('input[type="text"]');
                        if (inputs.length > 0) {
                            const parent = inputs[0].closest('.question, .cloze, .assessment');
                            return parent ? parent.innerText : '';
                        }
                        return '';
                    }''')
                    
                    return {
                        'inputs': inputs,
                        'context': context
                    }
                    
        except Exception as e:
            pass
        
        return None
    
    async def detect_short_answer_question(self) -> Optional[Dict]:
        """Detect short answer questions"""
        try:
            textarea = await self.page.query_selector('textarea.question-input, .short-answer, [data-testid="short-answer"]')
            if textarea:
                question_text = await self.page.evaluate('''() => {
                    const textarea = document.querySelector('textarea');
                    const parent = textarea.closest('.question, .assessment');
                    return parent ? parent.innerText : '';
                }''')
                
                return {
                    'textarea': textarea,
                    'question': question_text
                }
                
        except Exception as e:
            pass
        
        return None
    
    async def answer_multiple_choice_question(self, question_data: Dict):
        """Answer a multiple choice question using AI"""
        try:
            question_text = question_data['question']
            options = question_data['options']
            
            self.log(f"Question: {question_text[:100]}...")
            self.log(f"Options: {options}")
            
            # Take screenshot if enabled
            if self.config.get('screenshot_on_question', True):
                screenshot_path = f"question_{self.question_answered_count + 1}.png"
                await self.page.screenshot(path=screenshot_path)
                self.log(f"Screenshot saved: {screenshot_path}")
            
            # Get answer from AI
            answer = await self.get_ai_answer(question_text, options)
            self.log(f"AI selected answer: {answer}")
            
            # Click the selected option
            option_elements = question_data['option_elements']
            for i, option_text in enumerate(options):
                if answer.lower() in option_text.lower() or option_text.lower() in answer.lower():
                    await option_elements[i].click()
                    self.log(f"Clicked option: {option_text}")
                    break
            else:
                # If no match, click first option
                if option_elements:
                    await option_elements[0].click()
                    self.log("Clicked first option (no match found)")
            
            # Look for submit button
            submit_buttons = [
                'button:has-text("Submit")',
                'button:has-text("Answer")',
                'button:has-text("Check")',
                '.submit-button',
                '[data-testid="submit"]'
            ]
            
            for selector in submit_buttons:
                try:
                    await self.page.click(selector, timeout=2000)
                    self.log("Submitted answer")
                    break
                except:
                    continue
            
            self.question_answered_count += 1
            await asyncio.sleep(2)
            
        except Exception as e:
            self.log(f"ERROR answering MC question: {str(e)}", "ERROR")
    
    async def answer_cloze_question(self, question_data: Dict):
        """Answer a fill-in-the-blank question using AI"""
        try:
            context = question_data['context']
            inputs = question_data['inputs']
            
            self.log(f"Cloze context: {context[:100]}...")
            
            # Take screenshot if enabled
            if self.config.get('screenshot_on_question', True):
                screenshot_path = f"cloze_{self.question_answered_count + 1}.png"
                await self.page.screenshot(path=screenshot_path)
                self.log(f"Screenshot saved: {screenshot_path}")
            
            # Get answers from AI for each blank
            for i, input_field in enumerate(inputs):
                # Get surrounding sentence for context
                answer = await self.get_ai_cloze_answer(context, i + 1)
                self.log(f"AI answer for blank {i + 1}: {answer}")
                
                await input_field.fill(answer)
                await asyncio.sleep(0.5)
            
            # Submit the answer
            submit_buttons = [
                'button:has-text("Submit")',
                'button:has-text("Check")',
                '.submit-button'
            ]
            
            for selector in submit_buttons:
                try:
                    await self.page.click(selector, timeout=2000)
                    self.log("Submitted cloze answer")
                    break
                except:
                    continue
            
            self.question_answered_count += 1
            await asyncio.sleep(2)
            
        except Exception as e:
            self.log(f"ERROR answering cloze question: {str(e)}", "ERROR")
    
    async def answer_short_answer_question(self, question_data: Dict):
        """Answer a short answer question using AI"""
        try:
            question_text = question_data['question']
            textarea = question_data['textarea']
            
            self.log(f"Short answer question: {question_text[:100]}...")
            
            # Take screenshot if enabled
            if self.config.get('screenshot_on_question', True):
                screenshot_path = f"short_answer_{self.question_answered_count + 1}.png"
                await self.page.screenshot(path=screenshot_path)
                self.log(f"Screenshot saved: {screenshot_path}")
            
            # Get answer from AI
            answer = await self.get_ai_short_answer(question_text)
            self.log(f"AI generated answer: {answer[:100]}...")
            
            await textarea.fill(answer)
            
            # Submit
            submit_buttons = [
                'button:has-text("Submit")',
                'button:has-text("Save")',
                '.submit-button'
            ]
            
            for selector in submit_buttons:
                try:
                    await self.page.click(selector, timeout=2000)
                    self.log("Submitted short answer")
                    break
                except:
                    continue
            
            self.question_answered_count += 1
            await asyncio.sleep(2)
            
        except Exception as e:
            self.log(f"ERROR answering short answer: {str(e)}", "ERROR")
    
    async def get_ai_answer(self, question: str, options: List[str]) -> str:
        """Get AI answer for multiple choice question"""
        try:
            if not openai.api_key:
                self.log("WARNING: No OpenAI API key, selecting first option", "WARNING")
                return options[0] if options else ""
            
            prompt = f"""Question: {question}

Options:
{chr(10).join([f"{chr(65+i)}. {opt}" for i, opt in enumerate(options)])}

Select the best answer. Respond with just the letter (A, B, C, or D) or the full answer text."""
            
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are a helpful assistant that answers reading comprehension questions accurately."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=100,
                temperature=0.3
            )
            
            answer = response.choices[0].message.content.strip()
            return answer
            
        except Exception as e:
            self.log(f"ERROR getting AI answer: {str(e)}", "ERROR")
            return options[0] if options else ""
    
    async def get_ai_cloze_answer(self, context: str, blank_number: int) -> str:
        """Get AI answer for fill-in-the-blank question"""
        try:
            if not openai.api_key:
                self.log("WARNING: No OpenAI API key, returning 'answer'", "WARNING")
                return "answer"
            
            prompt = f"""Context: {context}

This is a fill-in-the-blank question. What word should go in blank #{blank_number}? 
Respond with just the single word that fits best."""
            
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are a helpful assistant that fills in blanks accurately based on context."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=50,
                temperature=0.3
            )
            
            answer = response.choices[0].message.content.strip()
            return answer
            
        except Exception as e:
            self.log(f"ERROR getting AI cloze answer: {str(e)}", "ERROR")
            return "answer"
    
    async def get_ai_short_answer(self, question: str) -> str:
        """Get AI answer for short answer question"""
        try:
            if not openai.api_key:
                self.log("WARNING: No OpenAI API key, returning generic answer", "WARNING")
                return "Based on the reading, this is an important concept."
            
            prompt = f"""Question: {question}

Provide a brief, accurate answer (2-3 sentences) based on typical reading comprehension."""
            
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are a helpful assistant that answers reading comprehension questions accurately and concisely."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=150,
                temperature=0.5
            )
            
            answer = response.choices[0].message.content.strip()
            return answer
            
        except Exception as e:
            self.log(f"ERROR getting AI short answer: {str(e)}", "ERROR")
            return "Based on the reading, this is an important concept."
    
    async def flip_page(self):
        """Flip to the next page"""
        try:
            # Common page navigation selectors
            next_page_selectors = [
                'button:has-text("Next")',
                'button:has-text(">")',
                '.next-page',
                '[data-testid="next-page"]',
                '.page-forward',
                'button[aria-label="Next page"]',
                '.arrow-right',
                '.pagination-next'
            ]
            
            for selector in next_page_selectors:
                try:
                    await self.page.click(selector, timeout=2000)
                    self.log("Flipped to next page")
                    await asyncio.sleep(1)
                    return
                except:
                    continue
            
            # Try keyboard navigation
            await self.page.keyboard.press('ArrowRight')
            self.log("Used keyboard to flip page")
            await asyncio.sleep(1)
            
        except Exception as e:
            self.log(f"ERROR flipping page: {str(e)}", "ERROR")
    
    async def stop(self):
        """Stop the bot and close browser"""
        self.is_running = False
        self.log("Stopping bot...")
        
        if self.browser:
            await self.browser.close()
            self.log("Browser closed")
        
        self.log(f"Session Summary:")
        self.log(f"  - Pages read: {self.pages_read}")
        self.log(f"  - Questions answered: {self.question_answered_count}")
        self.log(f"  - Book: {self.current_book or 'N/A'}")
    
    async def run(self):
        """Main run method"""
        try:
            await self.start()
            
            if await self.login():
                if await self.select_book():
                    await self.start_reading()
                else:
                    self.log("Failed to select book", "ERROR")
            else:
                self.log("Failed to login", "ERROR")
                
        except KeyboardInterrupt:
            self.log("Bot stopped by user")
        except Exception as e:
            self.log(f"FATAL ERROR: {str(e)}", "ERROR")
        finally:
            await self.stop()


async def main():
    bot = LightSailBot()
    await bot.run()


if __name__ == "__main__":
    asyncio.run(main())
